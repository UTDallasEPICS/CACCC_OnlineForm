 # Script to generate a PDF report after data has been parsed into .csv file and process it.
import HelperClass
import os

#Add Header for CAC# and page number
# save and delete after certain number
#GOING TO SHELL
# import statements
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import portrait
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, KeepTogether, tables, PageBreak
from reportlab.lib.units import inch, cm, mm
#from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer


#Check if the pdf folder is full and delete oldest pdf if folder is full 
def check_pdf_folder():
  print ( os.getcwd())
  try:
      path = os.path.join(os.path.expanduser("~"), "Desktop", "PDF_Folder")
      print("EXCESSIVE FILE DELETION METHOD PATH: " + path)
      os.chdir(path)
      print("CURRENT DIR IS: " + os.getcwd())
      files = sorted(os.listdir(os.getcwd()),key=os.path.getmtime)
      #list_of_files = os.listdir(path)    

  
      print("haha its working (1)")
      print(*files)
      
      print(len(files))
      print("oh")
      max_num_files = 5
      if len(files) >= max_num_files:
        oldest = files[0]
        # print ("Oldest: ", oldest)
        # print ("All by modified oldest to newest: ", files)
        os.remove(files[0])
        print ("REACHED " + str(max_num_files) + " FILES IN THE FOLDER, DELETING OLDEST FILE: " + oldest )

      else:
          print ("less than " + str(max_num_files) + " files in the folder, so NO files were deleted")
  except Exception as e:
      print ("Error with finding and deleting oldest file: " + str(e) )



csv_data = HelperClass.pre_processor('English.csv')

page_number = 1
section_number = 0
cac_assisstant = "CAC# " + csv_data[0][-1][1][0]
print(cac_assisstant)
date_submitted = csv_data[0][0]
child_first_name = csv_data[0][1][1][0]
child_middle_name = csv_data[0][2][1][0]
child_last_name = csv_data[0][3][1][0]

#removing the spaces from the date
date = date_submitted[1][0]
date = date[:9]
print("\ndate: " + date)
file_name = child_first_name + "_" + child_middle_name +"_"+child_last_name +"_"+ date +".pdf"
section_data = csv_data[0][1:20]
number_of_siblings = int(csv_data[0][20][1][0])
parent_data = csv_data[0][21:24]
parent_number = 0
relation_to_child = parent_data[1][1][0]
temp = section_data
temp_parent_data = []
#gender/ gender if other/ indicate special needs
# put in preprocessing
i = 0
for element in temp:
  if element[0] == 'Gender' or element[0] == 'Gender if Other' or element[0] == 'Indicate Special Needs for Child':
    continue
  if i == 5:
    temp_parent_data.append(parent_data[-1])
  temp_list = [element[0],element[1][-3:]]
  temp_parent_data.append(temp_list)
  i += 1
parent_data = temp_parent_data
final_data = csv_data[0][24:]

#[form][header/listOfValues][elementfromValuesList]
#if header [form][0]
#if value [form][1][0-10]
start_x = inch * .5
start_y = 750

print("\n file name: "+ file_name + "\n")
file_path = os.path.join(os.path.expanduser("~"), "Desktop", "PDF_Folder", file_name)
#print("\n file path: " + file_path + "\n")

#file_path = "PDF Folder/" + file_name

# PDF document layout
#canvas = canvas.Canvas(r"C:\Users\austin\Desktop\PDF Folder\pdf1.pdf", pagesize=letter)  # 8.5 x 11 inches
canvas = canvas.Canvas(r"" + file_path, pagesize=letter)  # 8.5 x 11 inches
#load workbook


textObject = canvas.beginText()
fontBold = 'Helvetica-Bold'
font = 'Helvetica'
textObject.setTextOrigin(start_x,start_y)  # maybe change y to inch * 10.5 or something
fontSize = 12
lineSpace = 1.5 * fontSize
lineUp = -lineSpace
textObject.setFont(fontBold, fontSize, lineSpace)  # line seperation 1.5
xPosRight = 0

#Add anything that needs to appear on every page here
def show_page():
  global page_number
  canvas.drawString(inch * 8, start_y, str(page_number))
  if(page_number != 1):
    canvas.drawString(start_x, inch * .5, cac_assisstant)
  page_number += 1;
  canvas.showPage()
  

def answer(element):
  textObject.setFont(font, fontSize, lineSpace)
  textObject.textOut(element + ' ')
  textObject.setFont(fontBold, fontSize, lineSpace)

#this one wraps the answer not really made xPosRight
# should've taken white space and character count and textObject.X
# and then used that info to create a Paragraph.
# Did this to save time for self as was short on it.
def answer_wrap(element):
  list_of_words = element.split(' ')
  for word in range(len(list_of_words)):
    list_of_words[word] = list_of_words[word].replace('\t', '')
  
  textObject.setFont(font, fontSize * .60, lineSpace * .60) #Decreases font size instead of wrapping b/c 

  word_count = 0
  for word in list_of_words:
    if word_count == 9 or word_count == 26:
      textObject.textLine(list_of_words[word_count]);
    else:
      textObject.textOut(list_of_words[word_count] + ' ')
    if word == 'case.' or word == 'name(s)':
      break
    word_count += 1

  textObject.setFont(fontBold, fontSize, lineSpace)

def draw_text_object(new_page = False):
  global textObject
  canvas.drawText(textObject)
  textObject = canvas.beginText(textObject.getX(), textObject.getY())
  textObject.setFont(fontBold, fontSize, lineSpace)
  if(new_page):
    textObject = canvas.beginText(start_x, start_y)
    textObject.setFont(fontBold, fontSize, lineSpace)

def draw_element(element, spaceAfter = 0, value_index = 0, endLine=False):
    global xPosRight
    textObject.setXPos(spaceAfter)
    xPosRight += spaceAfter

    values = element[1]

    textObject.textOut(element[0] + ': ')
    if(len(values[value_index]) > 20):
      answer_wrap(values[value_index])
    else:
      answer(values[value_index])

    if endLine == True:
        textObject.textLine()
        textObject.setXPos(-xPosRight)
        xPosRight = 0


def title_section():
    #Title
    textObject.setXPos(inch * 3)
    if 'Submitted' in date_submitted:
      textObject.textLine("Client Information")  # Move to center?
    else:
      textObject.textLine("Cliente Informacion")  # Move to center?
    textObject.setXPos(-inch * 3)
    textObject.textOut(cac_assisstant)
    #Put CAC# here?
    #Put Date here
    #drawNextElementInCSV(inch * 5, True)
    draw_element(date_submitted, inch * 5, 0, True)

    textObject.textLine()  # Blank Line after header section
    draw_text_object()

def section_content(parent = False):
  global section_data
  global section_number 
  inch_list = []
  ending_list = []

  if parent:
    inch_list = [0,5,
                 0,
                 0,2.5,2.5,
                 0,2.5,2.5,
                 0,2.5,2.5,
                 0,
                 0,
                 0,
                 0, 5]
    inch_list = list(map(lambda x: x * inch, inch_list))

    ending_list = [0,1,1,0,0,1,0,0,1,0,0,1,1,1,1,0,1]

  else:    
    inch_list = [0,5,
                 0,
                 0,2.5,
                 0,2.5,2.5,
                 0,2.5,2.5,
                 0,2.5,
                 0,
                 0,
                 0,
                 0,
                 0, 5]
    inch_list = list(map(lambda x: x * inch, inch_list))

    ending_list = [0,1,1,0,1,0,0,1,0,0,1,0,1,1,1,1,1,0,1]

  #Can optimize these two lists if the values are empty or small enough
  #to fit more on same line
  
  if parent:
    i = 0
    for element in parent_data:
      draw_element(element,inch_list[i],parent_number,ending_list[i])
      i += 1
  else:
    i = 0
    for element in section_data:
      draw_element(element,inch_list[i],section_number,ending_list[i])
      i += 1

  section_number += 1
  if(section_number % 3 == 0):
    draw_text_object(True)
    show_page()

def sibling_section():
  for sibling in range(number_of_siblings):
    textObject.textLine("SIBLING/STEPSIBLING INFORMATION")
    section_content()
    textObject.textLine()
  
  draw_text_object()

def parent_section():

  temp1 = [relation_to_child.upper(), "MOTHER", "FATHER"]
  for parent in range(3):
    textObject.textLine(temp1[parent])
    global parent_number
    section_content(True)
    textObject.textLine()
    parent_number += 1

  
  number_of_siblings
  #2 spaces
  if(number_of_siblings % 3 == 0):
    i = 0

def final_section():
  # These two help set where the text will be drawn
  inch_list = [0,
               0,
               0,
               0,2,2,
               0,3.5]
  inch_list = list(map(lambda x: x * inch, inch_list))

  ending_list = [1,1,1,0,0,1,0,1]
  i = 0

  for element in final_data:
    draw_element(element,inch_list[i],0,ending_list[i])
    i += 1



#Check if the pdf folder is full and delete oldest pdf if folder is full 
check_pdf_folder() 

#Making of Form
#child
title_section()
textObject.textLine("CHILD INFORMATION")
section_content()
textObject.textLine()
#sibling section
sibling_section()
textObject.textLine("PARENT INFORMATION")
parent_section()
textObject.textLine("ACKNOWLEDGEMENT INFORMATION")
final_section()

draw_text_object()
show_page()
canvas.save()




# Need to put date in CSV as well as form type.
