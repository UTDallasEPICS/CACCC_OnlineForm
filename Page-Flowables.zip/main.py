 # Script to generate a PDF report after data has been parsed into .csv file and process it.
import HelperClass

#Add Header for CAC# and page number
# save and delete after certain number
#GOING TO SHELL
# import statements
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import portrait
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, KeepTogether, tables, PageBreak
from reportlab.lib.units import inch, cm, mm
#from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

#load workbook
#Put name of file here
file_name = 'English'
csv_file = file_name + '.csv'
csv_data = HelperClass.pre_processor(csv_file)

# PDF document layout can be done here. For now is not done 

page_number = 1
section_number = 0
cac_assisstant = "CAC# " + csv_data[0][-1][1][0]
date_submitted = csv_data[0][0]
child_name = csv_data[0][1][1][0] + ' ' + csv_data[0][2][1][0]  + ' ' + csv_data[0][3][1][0]  
date = csv_data[0][0][1][0]
section_data = csv_data[0][1:20]
number_of_siblings = int(csv_data[0][20][1][0])
parent_data = csv_data[0][21:24]
parent_number = 0
relation_to_child = parent_data[1][1][0]
temp = section_data
temp_parent_data = []
#gender/ gender if other/ indicate special needs
# put in preprocessing
gender = temp[11][0]
gender_if_other = temp[12][0]
special_needs = temp[15][0]
i = 0
for element in temp:
  if element[0] == gender or element[0] == gender_if_other or element[0] == special_needs:
    continue
  if i == 5:
    temp_parent_data.append(parent_data[-1])
  temp_list = [element[0],element[1][-3:]]
  temp_parent_data.append(temp_list)
  i += 1
parent_data = temp_parent_data
final_data = csv_data[0][24:]

#Set section headers here
child_first_name = csv_data[0][1][1][0]
title_section_header = ''
# May want to make sibling headers an array to know which 
# ones are step siblings and which are by blood.
sibling_section_header = ''
child_section_header = ''
parent_section_header = ''
parent_section_headers = [relation_to_child.upper()]
acknowledgement_section_header = ''

if(child_first_name == 'Primero'):
  title_section_header = 'CLIENTE INFORMACIÓN'
  sibling_section_header = 'INFORMACIÓN DE HERMANO/A O HERMANASTRO/A'
  child_section_header = 'INFORMACIÓN DE NINO/A'
  parent_section_header = 'INFORMACIÓN DE LOS PADRES'
  parent_section_headers.append('MADRE')
  parent_section_headers.append('PADRE')
  acknowledgement_section_header = 'INFORMACIÓN DE RECONOCIMIENTO'

else:
  title_section_header = 'CLIENT INFORMATION'
  sibling_section_header = 'SIBLING/STEP SIBLING INFORMATION'
  child_section_header = 'CHILD INFORMATION'
  parent_section_header = 'PARENT INFORMATION'
  parent_section_headers.append('MOTHER')
  parent_section_headers.append('FATHER')
  acknowledgement_section_header = 'ACKNOWLEDGEMENT INFORMATION'

# Still need to put into a folder and delete pdfs after a certain number
# of them have been created.
pdf_file = './' + child_name + ' ' + date + '.pdf'
canvas = canvas.Canvas(
    pdf_file,
    pagesize=letter)  # 8.5 x 11 inches

#[form][header/listOfValues][elementfromValuesList]
#if header [form][0]
#if value [form][1][0-10]
start_x = inch * .5
start_y = 750

textObject = canvas.beginText()
fontBold = 'Helvetica-Bold'
font = 'Helvetica'
textObject.setTextOrigin(start_x,start_y)  # maybe change y to inch * 10.5 or something
fontSize = 12
lineSpace = 1.5 * fontSize
lineUp = -lineSpace
textObject.setFont(fontBold, fontSize, lineSpace)  # line seperation 1.5
xPosRight = 0

#Add anything that needs to appear on every page here
def show_page():
  global page_number
  canvas.drawString(inch * 8, start_y, str(page_number))
  if(page_number != 1):
    canvas.drawString(start_x, inch * .5, cac_assisstant)
  page_number += 1;
  canvas.showPage()
  

def answer(element):
  textObject.setFont(font, fontSize, lineSpace)
  textObject.textOut(element + ' ')
  textObject.setFont(fontBold, fontSize, lineSpace)

#this one wraps the answer not really made xPosRight
# should've taken white space and character count and textObject.X
# and then used that info to create a Paragraph.
# Did this to save time for self as was short on it.
def answer_wrap(element):
  list_of_words = element.split(' ')
  for word in range(len(list_of_words)):
    list_of_words[word] = list_of_words[word].replace('\t', '')
  
  textObject.setFont(font, fontSize, lineSpace)

  word_count = 0
  for word in list_of_words:
    if word_count == 9 or word_count == 26:
      textObject.textLine(list_of_words[word_count]);
    else:
      textObject.textOut(list_of_words[word_count] + ' ')
    # need to put spanish words here as well.
    if word == 'case.' or word == 'name(s)' or word == 'investigadoras.' or word == 'hijo/a.':
      break
    word_count += 1

  textObject.setFont(fontBold, fontSize, lineSpace)

def draw_text_object(new_page = False):
  global textObject
  canvas.drawText(textObject)
  textObject = canvas.beginText(textObject.getX(), textObject.getY())
  textObject.setFont(fontBold, fontSize, lineSpace)
  if(new_page):
    textObject = canvas.beginText(start_x, start_y)
    textObject.setFont(fontBold, fontSize, lineSpace)

def draw_element(element, spaceAfter = 0, value_index = 0, endLine=False):
    global xPosRight
    textObject.setXPos(spaceAfter)
    xPosRight += spaceAfter

    values = element[1]

    textObject.textOut(element[0] + ': ')
    if(len(values[value_index]) > 90):
      answer_wrap(values[value_index])
    else:
      answer(values[value_index])

    if endLine == True:
        textObject.textLine()
        textObject.setXPos(-xPosRight)
        xPosRight = 0


def title_section():
    #Title
    textObject.setXPos(inch * 3)
    textObject.textLine(title_section_header)  # Move to center?
    textObject.setXPos(-inch * 3)
    textObject.textOut(cac_assisstant)
    #Put CAC# here?
    #Put Date here
    #drawNextElementInCSV(inch * 5, True)
    draw_element(date_submitted, inch * 5, 0, True)

    textObject.textLine()  # Blank Line after header section
    draw_text_object()

def section_content(parent = False):
  global section_data
  global section_number 
  inch_list = []
  ending_list = []

  if parent:
    inch_list = [0,5,
                 0,
                 0,2.5,2.5,
                 0,2.5,2.5,
                 0,2.5,2.5,
                 0,
                 0,
                 0,
                 0, 5]
    inch_list = list(map(lambda x: x * inch, inch_list))

    ending_list = [0,1,1,0,0,1,0,0,1,0,0,1,1,1,1,0,1]

  else:    
    inch_list = [0,5,
                 0,
                 0,2.5,
                 0,2.5,2.5,
                 0,2.5,2.5,
                 0,2.5,
                 0,
                 0,
                 0,
                 0,
                 0, 5]
    inch_list = list(map(lambda x: x * inch, inch_list))

    ending_list = [0,1,1,0,1,0,0,1,0,0,1,0,1,1,1,1,1,0,1]

  #Can optimize these two lists if the values are empty or small enough
  #to fit more on same line
  
  if parent:
    i = 0
    for element in parent_data:
      draw_element(element,inch_list[i],parent_number,ending_list[i])
      i += 1
  else:
    i = 0
    for element in section_data:
      draw_element(element,inch_list[i],section_number,ending_list[i])
      i += 1

  section_number += 1
  if(section_number % 3 == 0):
    draw_text_object(True)
    show_page()

def sibling_section():
  for sibling in range(number_of_siblings):
    textObject.textLine(sibling_section_header)
    section_content()
    textObject.textLine()
  
  draw_text_object()

def parent_section():

  parent_section_headers = [relation_to_child.upper(), "MOTHER", "FATHER"]
  for parent in range(3):
    textObject.textLine(parent_section_headers[parent])
    global parent_number
    section_content(True)
    textObject.textLine()
    parent_number += 1

  
  number_of_siblings
  #2 spaces
  if(number_of_siblings % 3 == 0):
    i = 0

def final_section():
  # These two help set where the text will be drawn
  inch_list = [0,
               0,
               0,
               0,2,2,
               0,3.5]
  inch_list = list(map(lambda x: x * inch, inch_list))

  ending_list = [1,1,1,0,0,1,0,1]
  i = 0

  for element in final_data:
    draw_element(element,inch_list[i],0,ending_list[i])
    i += 1

#Making of Form
#child
title_section()
textObject.textLine(child_section_header)
section_content()
textObject.textLine()
#sibling section
sibling_section()
textObject.textLine(parent_section_header)
parent_section()
textObject.textLine(acknowledgement_section_header)
final_section()

draw_text_object()
show_page()
canvas.save()

# Need to put date in CSV as well as form type.
