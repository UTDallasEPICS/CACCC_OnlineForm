import csv
import re

def get_csv_data(file_path):
  csv_data = []
  with open(file_path) as csv_file:
    read_csv = csv.reader(csv_file, delimiter=',')
    for form in read_csv:
        csv_data.append(form)
  return csv_data

def pre_processor(file_path):
  raw_csv_data = get_csv_data(file_path)
  formatted_csv_data = setup_data(raw_csv_data)
  csv_data = formatted_csv_data
  
  return csv_data

def setup_data(csv_data):
  csv_data_dict = []

  for row in range(1,len(csv_data)):
    csv_data_dict.append((list(zip(csv_data[0],csv_data[row]))))

  keys = [i[0] for i in csv_data_dict[0]]
  keys = [i for n, i in enumerate(keys) if i not in keys[:n]] 
  values = []

  for dicts in csv_data_dict:
    for key in keys:
      value = []
      for elements in dicts:
        # Put code here due to inconsistences from Form
        
        if key == elements[0]:
          value.append(elements[1])
      values.append(value)
  
  csv_data_dict = []
  fixed_csv_data = fix_csv(keys,values)
  csv_data_dict.append(fixed_csv_data)
  csv_data = csv_data_dict


  #preparing final data here if needed. Better to use
  #Flowables or Paragraph.

  return csv_data

def fix_csv(keys, values):

  addressIndex = 0
  raceIndex = 0
  removeIndex = 0
  disablities_index = 0
  #Select child with same address i = 1 is start
  i = 0

  # Done so that it works for spanish form as well.
  address = keys[6]
  disability = keys[14]
  race = keys[17]
  same_address = keys[21]
  
  for key in keys:
    if key == address:
      addressIndex = i
    if key == disability:
      disablities_index = i
    if key == race:
      raceIndex = i
    if key == same_address:
      removeIndex = i
    i += 1
  
  #fixing RaceBug which prints twice
  fixed_race_list = []
  disablities_list = []
  for races in values[raceIndex]:
    fixed_race_list.append(re.sub(' \(.*?\)', '', races))

  for disabilities in values[disablities_index]:
    disablities_list.append(re.sub(' \(.*?\)', '', disabilities))

  values[raceIndex] = fixed_race_list
  values[disablities_index] = disablities_list

  keys.remove(keys[removeIndex])
  values.remove(values[removeIndex])
  checkIndex = removeIndex 

  indexes = []
  i = 1 # starts at 1 to offset for primary child
  for check in values[checkIndex]:
    if check:
      if 'Primary' in check or 'Primero' in check:
        indexes.append((i,0))
      elif '1' in check:
        indexes.append((i,1))
      elif '2' in check:
        indexes.append((i,2))
      elif '3' in check:
        indexes.append((i,3))
      elif '4' in check:
        indexes.append((i,4))
      elif '5' in check:
        indexes.append((i,5))         
    i += 1

  for index in indexes:
    #From address to zipcode
    for k in range(4):
      values[addressIndex+k][index[0]] = values[addressIndex+k][index[1]]

  keys.remove(keys[removeIndex])
  values.remove(values[removeIndex])

  
  csv_data = list(zip(keys,values))
  return csv_data
